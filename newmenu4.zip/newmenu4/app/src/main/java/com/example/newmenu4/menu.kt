package com.example.newmenu4

class menu(val food:Int, val name: String, val price: Int, val explain : String)