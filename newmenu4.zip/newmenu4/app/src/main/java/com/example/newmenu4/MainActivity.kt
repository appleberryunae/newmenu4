package com.example.newmenu4

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val menuList= arrayOf(
            menu(R.drawable.doncas,"세종대왕돈까스",5500,"세종대의 자랑 세종대왕돈까스!"),
            menu(R.drawable.doncas,"치즈돈까스",5500,"짱 맛있다!"),
            menu(R.drawable.doncas,"세종대왕돈까스",5500,"세종대의 자랑 세종대왕돈까스!"),
            menu(R.drawable.doncas,"세종대왕돈까스",5500,"세종대의 자랑 세종대왕돈까스!"),
            menu(R.drawable.doncas,"세종대왕돈까스",5500,"세종대의 자랑 세종대왕돈까스!"),
            menu(R.drawable.doncas,"세종대왕돈까스",5500,"세종대의 자랑 세종대왕돈까스!"),
            menu(R.drawable.doncas,"세종대왕돈까스",5500,"세종대의 자랑 세종대왕돈까스!"),
            menu(R.drawable.doncas,"세종대왕돈까스",5500,"세종대의 자랑 세종대왕돈까스!"),
            menu(R.drawable.doncas,"세종대왕돈까스",5500,"세종대의 자랑 세종대왕돈까스!"),
            menu(R.drawable.doncas,"세종대왕돈까스",5500,"세종대의 자랑 세종대왕돈까스!"),
            menu(R.drawable.doncas,"세종대왕돈까스",5500,"세종대의 자랑 세종대왕돈까스!"),


        )









        val rv_menu: RecyclerView =findViewById(R.id.rv_menu)

        rv_menu.layoutManager=LinearLayoutManager(this,LinearLayoutManager.VERTICAL,false)
        rv_menu.setHasFixedSize(true)

        rv_menu.adapter=MenuAdapter(menuList)
    }
}